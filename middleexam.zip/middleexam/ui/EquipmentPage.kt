import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.middleexam.R

class EquipmentPage<EditText> : AppCompatActivity() {
    private lateinit var equipmentList: MutableList<Equipment>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_equipment_page)

        equipmentList = equipmentList.toMutableList()

        val addButton: Button = findViewById(R.id.addButton)
        val removeButton: Button = findViewById(R.id.removeButton)
        val updateButton: Button = findViewById(R.id.updateButton)
        val nameEditText: EditText = findViewById(R.id.nameEditText)
        val quantityEditText: EditText = findViewById(R.id.quantityEditText)
        val conditionEditText: EditText = findViewById(R.id.conditionEditText)
        val infoTextView: TextView = findViewById(R.id.infoTextView)

        addButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val quantity = quantityEditText.text.toString().toIntOrNull() ?: 0
            val condition = conditionEditText.text.toString()
            val newEquipment = Equipment(equipmentList.size + 1, name, "", quantity, condition)
            equipmentList.add(newEquipment)
            infoTextView.text = "添加装备：$name"
        }

        removeButton.setOnClickListener {
            if (equipmentList.isNotEmpty()) {
                val removedEquipment = equipmentList.removeAt(equipmentList.size - 1)
                infoTextView.text = "移除装备：${removedEquipment.name}"
            } else {
                infoTextView.text = "没有装备可以移除"
            }
        }

        updateButton.setOnClickListener {
            if (equipmentList.isNotEmpty()) {
                val index = equipmentList.size - 1
                val updatedName = nameEditText.text.toString()
                val updatedQuantity = quantityEditText.text.toString().toIntOrNull() ?: 0
                val updatedCondition = conditionEditText.text.toString()
                equipmentList[index] = equipmentList[index].copy(name = updatedName, quantity = updatedQuantity, condition = updatedCondition)
                infoTextView.text = "更新装备：$updatedName"
            } else {
                infoTextView.text = "没有装备可以更新"
            }
        }
    }

    private fun findViewById(conditionEditText: Any): EditText {

    }
}