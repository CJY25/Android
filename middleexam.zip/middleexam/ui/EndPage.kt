import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.example.middleexam.R

class EndPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_end_page)

        val examOverButton: Button = findViewById(R.id.examOverButton)
        val examOverText: TextView = findViewById(R.id.examOverText)

        examOverButton.setOnClickListener {
            examOverText.text = "考试结束"
        }
    }
}