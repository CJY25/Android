import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.middleexam.R

class Index : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_index)

        val commodityCount: TextView = findViewById(R.id.commodityCount)
        val equipmentCount: TextView = findViewById(R.id.equipmentCount)

        commodityCount.text = "商品数量：${commodityList.size}"
        equipmentCount.text = "装备信息：${equipmentList.size}"
    }
}