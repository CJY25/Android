
data class Commodity(
    val id:Int,
    val name:String,
    val price:Double,
    val quantity:Int,
    val description:String
)
data class Equipment(
    val id:Int,
    val name: String,
    val category: String,
    val quantity: Int,
    val condition: String
)
val commodityList = listOf(
    Commodity(1,"Apple",1.0,10,"Fresh and juicy"),
    Commodity(2,"Banana",0.5,20,"Rich in potassium"),
    Commodity(3,"Milk",2.0,5,"Fresh dairy product"),
    Commodity(4,"Bread",1.5,15,"Whole wheat bread"),
    Commodity(5,"Eggs",3.0,8,"Farm fresh eggs")
)
val equipmentList= listOf(
    Equipment(1,"Treadmill","Fitness",2,"Good condition"),
    Equipment(2,"Dumbbells","Fitness",5,"Various weights"),
    Equipment(3,"Yoga mat","Fitness",10,"Eco-friendly material"),
    Equipment(4,"Jump rope","Fitness",20,"Adjustable length"),
    Equipment(5,"Resistance bands","Fitness",15,"Different resistance levels")
)