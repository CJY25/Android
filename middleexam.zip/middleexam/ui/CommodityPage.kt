import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class CommodityPage : AppCompatActivity() {
    private lateinit var commodityList: MutableList<Commodity>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_commodity_page)

        commodityList = commodityList.toMutableList()

        val addButton: Button = findViewById(R.id.addButton)
        val removeButton: Button = findViewById(R.id.removeButton)
        val updateButton: Button = findViewById(R.id.updateButton)
        val nameEditText: EditText = findViewById(R.id.nameEditText)
        val quantityEditText: EditText = findViewById(R.id.quantityEditText)
        val descriptionEditText: EditText = findViewById(R.id.descriptionEditText)
        val infoTextView: TextView = findViewById(R.id.infoTextView)

        addButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val quantity = quantityEditText.text.toString().toIntOrNull() ?: 0
            val description = descriptionEditText.text.toString()
            val newCommodity = Commodity(commodityList.size + 1, name, 0.0, quantity, description)
            commodityList.add(newCommodity)
            infoTextView.text = "添加商品：$name"
        }

        removeButton.setOnClickListener {
            if (commodityList.isNotEmpty()) {
                val removedCommodity = commodityList.removeAt(commodityList.size - 1)
                infoTextView.text = "移除商品：${removedCommodity.name}"
            } else {
                infoTextView.text = "没有商品可以移除"
            }
        }

        updateButton.setOnClickListener {
            if (commodityList.isNotEmpty()) {
                val index = commodityList.size - 1
                val updatedName = nameEditText.text.toString()
                val updatedQuantity = quantityEditText.text.toString().toIntOrNull() ?: 0
                val updatedDescription = descriptionEditText.text.toString()
                commodityList[index] = commodityList[index].copy(name = updatedName, quantity = updatedQuantity, description = updatedDescription)
                infoTextView.text = "更新商品：$updatedName"
            } else {
                infoTextView.text = "没有商品可以更新"
            }
        }
    }
}